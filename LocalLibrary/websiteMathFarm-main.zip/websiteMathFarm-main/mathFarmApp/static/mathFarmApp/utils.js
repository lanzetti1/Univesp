function generateRandomInteger(max) {
    return Math.floor(Math.random() * max) + 1;
}

